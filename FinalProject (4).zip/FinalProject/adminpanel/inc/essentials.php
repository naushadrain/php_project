<?php
// frontend purpose data
define('SITE_URL','http://127.0.0.1/FinalProject/');
define('ABOUT_IMG_PATH',SITE_URL.'images/about/'); // froent part show image path 
define('CAROUSEL_IMG_PATH',SITE_URL.'images/carousel/');
define('FACILITIES_IMG_PATH',SITE_URL.'images/facilities/');
define('ROOMS_IMG_PATH',SITE_URL.'images/rooms/');

// backend upload  process needs this data
define('UPLOAD_IMAGE_PATH',$_SERVER['DOCUMENT_ROOT'].'/FinalProject/images/'); // PATH RETURN
define('ABOUT_FOLDER','about/');  // absulate path
define('CAROUSEL_FOLDER','carousel/'); 
define('FACILITIES_FOLDER','facilities/');
define('ROOMS_FOLDER','rooms/');
//define('USERS_FOLDER','users/');  
// constant define 

//sendgrid api key

define('SENDGRID_API_KEY',"SG>Nq5jKLk5T001JJ_WeMMK8g.EwhejpWWWIIRpLifJbFeQxfklJA1ghkLno9gh4SKr8");


function adminlogin(){
    session_start();
    if(!(isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true)){
        echo "<script>
            window.location.href='index.php';
        </script>";
        exit;
    }
 }

 function redirect($url){
    echo "
    <script>
    window.location.href='$url';
    </script>";
    exit;
}
function alert($type, $msg)
{
    $bs_class = ($type=="success") ? "alert-succes" : "alert-danger";
    echo <<<alert
        <div class="alert $bs_class alert-warning alert-dismissible fade show custom-alert" role="alert">
            <strong class="me-3">$msg</strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
     alert;
}

function uploadImage($image,$folder){
    $valid_mime = ['image/jpeg','image/png','image/webp'];
    $img_mime = $image['type'];
     //It's a way of identifying files on the Internet according to their nature and format
    if(!in_array($img_mime,$valid_mime)){
        return 'inv_img';// invalid image mime or format

    }
    else if(($image['size']/(1024*1024))>2){
        return 'inv_size'; //greater than 2mb

    }
    else{
        $ext = pathinfo($image['name'],PATHINFO_EXTENSION);
        $rname = 'IMG_'.random_int(11111,999999).".$ext"; // coancatenate next string one part
        $img_path = UPLOAD_IMAGE_PATH.$folder.$rname; // image which name upload and upload address folder
       if( move_uploaded_file($image['tmp_name'],$img_path)){
        return $rname;
       }
       else{
        return 'upd_failed';
       }

    }
}

function deleteImage($image,$folder){

    // surver site and main folder both part delete
    if(unlink(UPLOAD_IMAGE_PATH.$folder.$image)){
        return true;
    }
    else{
        return false;
    }
}

function uploadSVGImage($image,$folder){
    $valid_mime = ['image/svg+xml'];
    $img_mime = $image['type'];
     //It's a way of identifying files on the Internet according to their nature and format
    if(!in_array($img_mime,$valid_mime)){
        return 'inv_img';// invalid image mime or format

    }
    else if(($image['size']/(1024*1024))>1){
        return 'inv_size'; //greater than 1mb

    }
    else{
        $ext = pathinfo($image['name'],PATHINFO_EXTENSION);
        $rname = 'IMG_'.random_int(11111,999999).".$ext"; // coancatenate next string one part
        $img_path = UPLOAD_IMAGE_PATH.$folder.$rname; // image which name upload and upload address folder
       if( move_uploaded_file($image['tmp_name'],$img_path)){
        return $rname;
       }
       else{
        return 'upd_failed';
       }

    }
}

function uploadUserImage($image){
    $valid_mime = ['image/jpeg','image/png','image/webp'];
    $img_mime = $image['type'];
     //It's a way of identifying files on the Internet according to their nature and format
    if(!in_array($img_mime,$valid_mime)){
        return 'inv_img';// invalid image mime or format

    }
    else{
        $ext = pathinfo($image['name'],PATHINFO_EXTENSION);
        $rname = 'IMG_'.random_int(11111,999999).".jpeg"; // coancatenate next string one part
        $img_path = UPLOAD_IMAGE_PATH.USERS_FOLDER.$rname; // image which name upload and upload address folder

        if($ext == 'png' || $ext =='PNG'){
           $img =  imagecreatefrompng($image['tmp_name']);
        }
        else if($ext == 'webp' || $ext =='WEBP'){
            $img =  imagecreatefromwebp($image['tmp_name']);
         }
         else{
            $img = imagecreatefromjpeg($image['tmp_name']);
         }



       if(imagejpeg($img,$img_path,75)){
        return $rname;
       }
       else{
        return 'upd_failed';
       }

    }

}


?>