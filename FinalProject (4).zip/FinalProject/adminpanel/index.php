<?php  
require('inc/connection.php');
require('inc/essentials.php');
session_start();
if((isset($_SESSION['adminLogin']) && $_SESSION['adminLogin'] == true)){
    redirect('dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adminpanel</title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <?php require('inc/links.php'); ?>
</head>
<style>
    div.login-form {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 400px;
    }
</style>

<body class="bg-light">

    <div class="login-form text-center rounded bg-white shadow overflow-hidden">
        <form method="post" id="form-data">

            <h4 class="bg-dark text-white py-3">ADMIN LOGIN PANEL</h4>
            <div class="p-4">
                <div class="mb-3">
                    <input name="admin_name" type="text" class="form-control shadow-none text-center"
                        placeholder="Admin Name" required>

                </div>
                <div class="mb-4">
                    <input name="admin_pass" type="password" class="form-control shadow-none text-center"
                        placeholder="Admin Password" required>
                </div>
                <div class="mb-4">
                <div class="g-recaptcha w-100 m-0 p-0 text-center" data-sitekey="6LdjzUkpAAAAABkp8Qkh7_f_tJv8H_AA4MjDLk3F"></div>
                </div>
                <button name="login" type="submit" class="btn text-white custom-bg shadow-none">LOGIN</button>
            </div>
        </form>
    </div>

    <?php
    // if (isset($_POST['login'])) {
    //     // print_r($_POST);
    //     $frm_data = filteration($_POST);
    //     $query = "SELECT  * FROM `admin_cred` WHERE `admin_name`=? AND `admin_pass`=?";
    //     $values = [$frm_data['admin_name'], $frm_data['admin_pass']];
    //     // select($query,$values,"ss");
    //     $res = select($query, $values, "ss");
    //     if ($res->num_rows==1) {
    //         // echo "got user";
    //         $row = mysqli_fetch_assoc($res);
    //         // session_start();
    //         $_SESSION['adminLogin'] = true;
    //         $_SESSION['adminId'] = $row['sr_no'];
    //          redirect('dashboard.php');
            
    //     } else {
    //         alert('error', 'Login failed -Invalid Credentials!');
    //     }

    // }

if(isset($_POST['login']) && $_POST['g-recaptcha-response']!="")
{
 
 
 $secret = '6LdjzUkpAAAAAEXYVAESa66h6nCUIRVMlS44yHBK';
 
 $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
 
 $responseData = json_decode($verifyResponse);
 
 if($responseData->success)
 {
 
      $frm_data = filteration($_POST);
        $query = "SELECT  * FROM `admin_cred` WHERE `admin_name`=? AND `admin_pass`=?";
        $values = [$frm_data['admin_name'], $frm_data['admin_pass']];
        // select($query,$values,"ss");
        $res = select($query, $values, "ss");
        if ($res->num_rows==1) {
            // echo "got user";
            $row = mysqli_fetch_assoc($res);
            // session_start();
            $_SESSION['adminLogin'] = true;
            $_SESSION['adminId'] = $row['sr_no'];
             redirect('dashboard.php');
             exit;
            
        } else {
            alert('error', 'Login failed');
        }
    }
 
 }
 else{
    alert('error','are you robot!');
 }



    ?>

    <?php require('inc/script.php'); ?>

    <script>
        document.getElementById('form-data').reset();
        
    </script>
</body>
</html>